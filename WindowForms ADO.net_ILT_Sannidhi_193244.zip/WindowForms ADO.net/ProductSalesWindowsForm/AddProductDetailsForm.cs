﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductSalesWindowsApplication
{
    public partial class AddProductDetailsForm : Form
    {
        public AddProductDetailsForm()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                ProductSalesDataLayer dc = new ProductSalesDataLayer();
                dc.AddProductDetails(txtpid.Text, txtpname.Text);
                MessageBox.Show("Record has been saved successfully");
                txtpid.Text = "";
                txtpname.Text = "";
               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
