﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace ProductSalesWindowsApplication
{
    public partial class AddSalesDetailsForm : Form
    {
        public AddSalesDetailsForm()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            try
            {
                ProductSalesDataLayer dc = new ProductSalesDataLayer();
                dc.AddSalesDetails(txtsid.Text, cmbpid.Text,txtyear.Text,txtqual.Text, txtprice.Text );
                MessageBox.Show("Record has been saved successfully");
                txtsid.Text = "";
                cmbpid.Text = "";
                txtyear.Text = "";
                txtqual.Text = "";
                txtprice.Text = "";

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void AddSalesDetailsForm_Load(object sender, EventArgs e)
        {
            SqlConnection con;
            SqlCommand cmd;

            con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=ProductSales;Integrated Security=True");
            con.Open();
            string s = "select PRODUCT_ID from PRODUCTS";
            cmd = new SqlCommand(s, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cmbpid.Items.Add(dr[0].ToString());
            }
            dr.Close();
        }
    }
}
