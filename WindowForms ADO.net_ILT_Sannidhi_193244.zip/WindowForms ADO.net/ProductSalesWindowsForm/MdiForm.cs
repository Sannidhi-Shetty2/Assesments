﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductSalesWindowsApplication
{
    public partial class MdiForm : Form
    {
        public MdiForm()
        {
            InitializeComponent();
        }

        private void addProductDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddProductDetailsForm ae = new AddProductDetailsForm();
            ae.MdiParent = this;
            ae.Show();
        }

        private void addSalesDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSalesDetailsForm ad = new AddSalesDetailsForm();
            ad.MdiParent = this;
          
            ad.Show();
            
        }

        private void queriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowDetails sd = new ShowDetails();
            sd.MdiParent = this;
            sd.Show();
        }
    }
}
