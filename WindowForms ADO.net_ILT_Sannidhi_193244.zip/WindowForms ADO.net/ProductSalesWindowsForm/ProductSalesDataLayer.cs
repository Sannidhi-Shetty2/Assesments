﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ProductSalesWindowsApplication
{
    class ProductSalesDataLayer
    {
        SqlConnection con;
        SqlCommand cmd;
        DataSet ds;
        SqlDataAdapter ad;

        public ProductSalesDataLayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=ProductSales;Integrated Security=True");
            con.Open();
        }

        public void AddProductDetails(string PRODUCT_ID, string PRODUCT_NAME)
        {
            string sql = "InsertDataProducts";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@PRODUCT_ID", SqlDbType.Int).Value = PRODUCT_ID;
            cmd.Parameters.Add("@PRODUCT_NAME", SqlDbType.VarChar ,30).Value = PRODUCT_NAME;
           
            cmd.ExecuteNonQuery();
        }
        public void AddSalesDetails(string SALE_ID, string PRODUCT_ID, string YEAR, string Quantity, string PRICE)
        {
            string sql = "InsertDataSales";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@SALE_ID", SqlDbType.Int).Value = SALE_ID;
            cmd.Parameters.Add("@PRODUCT_ID", SqlDbType.Int).Value = PRODUCT_ID;
            cmd.Parameters.Add("@YEAR", SqlDbType.Int).Value = YEAR;
            cmd.Parameters.Add("@Quantity", SqlDbType.Int).Value = Quantity;
            cmd.Parameters.Add("@PRICE", SqlDbType.Int).Value = PRICE;

            cmd.ExecuteNonQuery();
        }
        public DataSet GetAllProducts()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from PRODUCTS",
               con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet GetAllSales()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from SALES",
               con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query1()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select p.PRODUCT_NAME from PRODUCTS p where p.PRODUCT_ID not in (select distinct PRODUCT_ID from SALES)", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query2()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select PRODUCT_NAME from PRODUCTS p, SALES S1, SALES S2 where p.PRODUCT_ID = s1.PRODUCT_ID and s1.YEAR =2012 and s2.YEAR = 2011 and s1.PRODUCT_ID = s2.PRODUCT_ID and s1.Quantity < s2.Quantity ", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query3()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select p.PRODUCT_NAME, Sum(s.Quantity)  TotalSales   from PRODUCTS p join SALES s on p.PRODUCT_ID = s.PRODUCT_ID group by PRODUCT_NAME; ", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query4()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select p.PRODUCT_NAME, s.YEAR, s.Quantity from PRODUCTS p join SALES s on p.PRODUCT_ID = s.PRODUCT_ID where s.Quantity > (select avg(Quantity) from SALES s1 where s1.PRODUCT_ID = s.PRODUCT_ID)", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query5()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select s.YEAR, s.Quantity as IPhone_Quantity, s1.Quantity as Samsung_Quantity, s.PRICE as IPhone_Price, s1.PRICE as Samsung_Price from PRODUCTS p1, PRODUCTS p2, SALES s, SALES s1 where p1.PRODUCT_ID = s.PRODUCT_ID and p2.PRODUCT_ID = s1.PRODUCT_ID and p1.PRODUCT_NAME = 'IPhone' and p2.PRODUCT_NAME = 'Samsung' and s.YEAR = s1.YEAR", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query6()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select YEAR, count(*) as NoOfProducts from SALES group by YEAR", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
        public DataSet Query7()
        {
            ds = new DataSet();
            ad = new SqlDataAdapter("select PRODUCT_NAME, Year from (select p.PRODUCT_NAME, s.YEAR, Rank() over (partition by s.year order by s.quantity desc )R from PRODUCTS p , SALES s where p.PRODUCT_ID = s.PRODUCT_ID)a where r = 1", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
    }
}
