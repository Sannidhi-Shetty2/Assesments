﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace StudentCourseManagement
{
    public partial class AddStudentForm : Form
    {
        public AddStudentForm()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                dc.AddStudent(txtsid.Text, txtsname.Text,
                    txtdate.Text, txtscity.Text, txtsqual.Text, 
                    txtsemail.Text, txtsphone.Text);
                MessageBox.Show("Record has been saved successfully");
                txtsid.Text = "";
                txtsname.Text = "";
                txtdate.Text = "";
                txtscity.Text = "";
                txtsqual.Text = "";
                txtsemail.Text = "";
                txtsphone.Text = "";

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void AddStudentForm_Load(object sender, EventArgs e)
        {

        }
    }
}
