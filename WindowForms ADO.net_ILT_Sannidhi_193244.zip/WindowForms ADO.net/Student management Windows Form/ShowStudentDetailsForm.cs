﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentCourseManagement
{
    public partial class ShowStudentDetails : Form
    {
        public ShowStudentDetails()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                DataSet ds = dc.GetAllStudent();
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void ShowStudentDetails_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con;
                SqlCommand cmd;

                con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=TechPro;Integrated Security=True");
                con.Open();
                string s = "select sid from student";
                cmd = new SqlCommand(s, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cmbsid.Items.Add(dr[0].ToString());
                }
                dr.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                DataSet ds = dc.StudentCourseDetails(cmbsid.Text);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                DataSet ds = dc.StudentBatchDetails(cmbsid.Text);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
