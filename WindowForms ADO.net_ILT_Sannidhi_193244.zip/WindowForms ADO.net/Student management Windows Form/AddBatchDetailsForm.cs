﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;


namespace StudentCourseManagement
{
    public partial class AddBatchForm : Form
    {
        public AddBatchForm()
        {
            InitializeComponent();
        }

        private void cmbcid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            SqlConnection con;
            SqlCommand cmd;
            
            con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=TechPro;Integrated Security=True");
            con.Open();
            string s = "select courseid from course";
            cmd = new SqlCommand(s, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cmbcid.Items.Add(dr[0].ToString());
            }
            dr.Close();
        }

        private void btnsave3_Click(object sender, EventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                dc.AddBatchDetails(txtbid.Text, txtbdate.Text,
                    txtbstrength.Text, cmbcid.Text);
                MessageBox.Show("Record has been saved successfully");
                txtbid.Text = "";
                txtbdate.Text = "";
                txtbstrength.Text = "";
                cmbcid.Text = "";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
