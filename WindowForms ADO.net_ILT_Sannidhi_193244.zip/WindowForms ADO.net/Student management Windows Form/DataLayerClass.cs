﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace StudentCourseManagement
{
    class DataLayerClass
    {
        SqlConnection con;
        SqlCommand cmd;
        DataSet ds;
        SqlDataAdapter ad;
        public DataLayerClass()
        {
            con = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=Techpro;Integrated Security=True");
            con.Open();
        }
        public void AddStudent(string sid, string sname, string sdob, 
            string scity, string squal, string semail, string sphone )
        {
            string sql = "InsertDataStudent";
            cmd = new SqlCommand(sql,con);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.Add("@sid", SqlDbType.Char).Value
                               = sid;
            cmd.Parameters.Add("@sname", SqlDbType.VarChar, 50).Value
                               = sname;
            cmd.Parameters.Add("@sdob", SqlDbType.Date).Value
                               = sdob;
            cmd.Parameters.Add("@scity", SqlDbType.VarChar, 20).Value
                               = scity;
            cmd.Parameters.Add("@squal", SqlDbType.VarChar, 20).Value
                               = squal;
            cmd.Parameters.Add("@semail", SqlDbType.VarChar, 30).Value
                               = semail;
            cmd.Parameters.Add("@sphone", SqlDbType.VarChar, 20).Value
                               = sphone;

            cmd.ExecuteNonQuery();
        


         }
        public DataSet GetAllStudent()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from student",
               con);
            ad.Fill(ds);
            return ds;
        }
        public void AddCourseDetails(string courseid, string coursename, string coursecategory, string coursefees, string courseduration  )
        {
            string sql = "InsertDataCourse";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@courseid", SqlDbType.Char).Value
                               = courseid;
            cmd.Parameters.Add("@coursename", SqlDbType.VarChar, 40).Value
                               = coursename;
            
            cmd.Parameters.Add("@coursecategory", SqlDbType.VarChar, 20).Value
                               = coursecategory;
            cmd.Parameters.Add("@coursefees", SqlDbType.Decimal).Value
                               = coursefees;
            cmd.Parameters.Add("@courseduration", SqlDbType.Int).Value
                               = courseduration;
            

            cmd.ExecuteNonQuery();
        }
        public DataSet GetAllCourse()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from course",
               con);
            ad.Fill(ds);
            return ds;
        }
         public void AddBatchDetails(string batchid, string bsdate, string bstrength, string courseid)
        {
            string sql = "InsertDataBatch";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@batchid", SqlDbType.Char).Value = batchid;
            cmd.Parameters.Add("@bsdate", SqlDbType.Date).Value = bsdate;
            cmd.Parameters.Add("@bstrength", SqlDbType.Int).Value = bstrength;
            cmd.Parameters.Add("@courseid", SqlDbType.Char).Value = courseid;
            cmd.ExecuteNonQuery();
        }
        public DataSet GetAllBatch()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from batch",
               con);
            ad.Fill(ds);
            return ds;
        }

        public void AddEnrollmentDetails(string batchid, string sid, string edate)
        {
            string sql = "InsertDataEnrollment";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@batchid", SqlDbType.Char).Value = batchid;
            cmd.Parameters.Add("@sid", SqlDbType.Char).Value = sid;
            cmd.Parameters.Add("@edate", SqlDbType.Date).Value = edate;
            cmd.ExecuteNonQuery();
        }
        public DataSet GetAllEnrollment()
        {
            ds = new DataSet();
            ad =
               new SqlDataAdapter("select * from enrollment",
               con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet StudentCourseDetails(string sid)
        {

           
           
            ds = new DataSet();
            ad = new SqlDataAdapter("select c.courseid,c.coursename,c.coursecategory,c.coursefees,c.courseduration from course c inner join batch b on c.courseid = b.courseid join enrollment e on b.batchid = e.batchid join student s on e.sid = s.sid and s.sid = '" + sid + "'", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;

        }
        public DataSet StudentBatchDetails(string sid)
        {

            ds = new DataSet();
            ad = new SqlDataAdapter("select b.batchid, b.bsdate, b.bstrength, b.courseid from batch b inner join enrollment e on b.batchid = e.batchid inner join student s on e.sid = s.sid and s.sid = '" + sid + "'", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;

        }

        public DataSet CourseDetails(string cid)
        {
           
            ds = new DataSet();
            ad = new SqlDataAdapter("select * from course where courseid = '" + cid + "'", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }

        public DataSet CourseRevenue(string cid)
        {
           
            ds = new DataSet();
            ad = new SqlDataAdapter("select a.courseid, NoOfStudents, NoOfStudents * coursefees as TotalFees from( select courseid ,count (*) as NoOfStudents from batch b join enrollment e on b.batchid = e.batchid group by courseid)a join course c on a.courseid = c.courseid and c.courseid ='" + cid + "'", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }

        public DataSet BatchDetails(string bid)
        {
            
            ds = new DataSet();
            ad = new SqlDataAdapter("select * from batch where batchid = '" + bid + "'", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }

        public DataSet BatchVacantDetails(string bid)
        {
            
            ds = new DataSet();
            ad = new SqlDataAdapter("select b.batchid, a.NoOfStudents, b.bstrength - a.NoOfStudents as 'NoOfVacant' from (select batchid, count(*) as NoOfStudents from enrollment group by batchid)a join batch b on b.batchid = a.batchid", con);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            return dt;
        }
    }
}
