﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagement
{
    public partial class AddCourseForm : Form
    {
        public AddCourseForm()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnsave2_Click(object sender, EventArgs e)
        {
            try
            { 

            DataLayerClass dc = new DataLayerClass();
            dc.AddCourseDetails(txtcid.Text, txtcname.Text,
                txtccategory.Text, txtcfees.Text, txtcduration.Text);
            MessageBox.Show("Record has been saved successfully");
            txtcid.Text = "";
            txtcname.Text = "";
            txtccategory.Text = "";
            txtcfees.Text = "";
            txtcduration.Text = "";
                }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
