﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagement
{
    public partial class ShowEnrollmentDetails : Form
    {
        public ShowEnrollmentDetails()
        {
            InitializeComponent();
        }

        private void ShowEnrollmentDetails_Load(object sender, EventArgs e)
        {
            try
            {
                DataLayerClass dc = new DataLayerClass();
                DataSet ds = dc.GetAllEnrollment();
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
