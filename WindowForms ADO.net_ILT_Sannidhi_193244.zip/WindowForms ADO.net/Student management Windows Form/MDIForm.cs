﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagement
{
    public partial class MDIForm : Form
    {
        public MDIForm()
        {
            InitializeComponent();
        }

        private void addStudentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStudentForm ae = new AddStudentForm();
            ae.MdiParent = this;
            ae.Show();
        }

        private void addCourseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddCourseForm ac = new AddCourseForm();
            ac.MdiParent = this;
            ac.Show();
        }

        private void addBatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBatchForm ab = new AddBatchForm();
            ab.MdiParent = this;
            ab.Show();
        }

        private void addEnrollmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEnrollmentForm af = new AddEnrollmentForm();
            af.MdiParent = this;
            af.Show();
        }

        private void studentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStudentDetails ss = new ShowStudentDetails();
            ss.MdiParent = this;
            ss.Show();
        }

        private void courseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowCourseDetails sc = new ShowCourseDetails();
            sc.MdiParent = this;
            sc.Show();

        }

        private void batchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowbatchDetails sb = new ShowbatchDetails();
            sb.MdiParent = this;
            sb.Show();

        }

        private void enrollmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowEnrollmentDetails se = new ShowEnrollmentDetails();
            se.MdiParent = this;
            se.Show();
        }
    }
}
