﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    public delegate void DelegateDecision(int[] s);

    class Program
    {
        static void Odd(int[] s)
        {
            Console.WriteLine("Odd Numbers are");
            for (int i = 0; i < s.Length; i++)
            {
                
                if (s[i] % 2 == 1)
                    Console.WriteLine( s[i] + " ");

            }
        }
        static void Even(int[] s)
        {
            Console.WriteLine("Even Numbers are");
            for (int i = 0; i < s.Length; i++)
            {
                
                if (s[i] % 2 == 0)
                Console.WriteLine(s[i] + " ");

            }
        }
        static void Prime(int[] s)
        {
            Console.WriteLine("Prime Numbers are");
            int j;
            bool isprime = true;
            for (int i = 0; i < s.Length; i++)
            {
                for ( j = 2; j <= s[i]; j++)
                {
                    if(i!=j && i%j==0)
                    {
                        isprime = false;
                        break;
                    }
                }
                if (isprime)
                {
                    Console.WriteLine(s[i] + " ");
                }
            }

        }
       
        static void Main(string[] args)
        {
            DelegateDecision d1 = (a) =>
            {
                Odd(a);
            };
            DelegateDecision d2 = (a) =>
            {
                Even(a);
            };
            DelegateDecision d3 = (a) =>
            {
                Prime(a);
            };

            int[] s = { 1, 3, 45, 87, 25, 40, 28, 2, 4, 6 };

           void dec(int[] b, DelegateDecision d)
            {
                d(s);
            }
            dec(s, d1);
            dec(s, d2);
            dec(s, d3);
            Console.ReadLine();
        }

    }
}
