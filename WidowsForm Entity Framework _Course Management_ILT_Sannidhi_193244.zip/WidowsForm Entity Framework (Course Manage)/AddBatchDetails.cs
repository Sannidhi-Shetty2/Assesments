﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class AddBatchDetails : Form
    {
        public AddBatchDetails()
        {
            InitializeComponent();
        }

        private void btnsave3_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            batch b = new batch();
            b.batchid = txtbid.Text;
            b.bsdate = DateTime.Parse(txtbdate.Text);
            b.bstrength = int.Parse(txtbstrength.Text);
            b.courseid = cmbcid.Text;
            tc.batches.Add(b);
            tc.SaveChanges();
            MessageBox.Show("Saved Successfully");
            txtbdate.Clear();
            txtbid.Clear();
            txtbstrength.Clear();
            
        }

        private void AddBatchDetails_Load(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
           
            foreach(var item in tc.courses)
            {
                cmbcid.Items.Add(item.courseid).ToString();
            }
        }
    }
}
