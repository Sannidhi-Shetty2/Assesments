﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class AddStudentDetails : Form
    {
        public AddStudentDetails()
        {
            InitializeComponent();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            student s = new student();
            s.sid = txtsid.Text;
            s.sname = txtsname.Text;
            s.sdob = DateTime.Parse(txtdate.Text);
            s.scity = txtscity.Text;
            s.squal = txtsqual.Text;
            s.semail = txtsemail.Text;
            s.sphone = txtsphone.Text;
            tc.students.Add(s);
            tc.SaveChanges();
            MessageBox.Show("Saved Successfully");
            txtsid.Clear();
            txtsname.Clear();
            txtdate.Clear();
            txtsemail.Clear();
            txtscity.Clear();
            txtsqual.Clear();
            txtsphone.Clear();


        }
    }
}
