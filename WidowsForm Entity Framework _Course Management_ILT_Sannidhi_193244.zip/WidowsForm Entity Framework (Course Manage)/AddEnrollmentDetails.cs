﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class AddEnrollmentDetails : Form
    {
        public AddEnrollmentDetails()
        {
            InitializeComponent();
        }

        private void btnsave4_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            enrollment r = new enrollment();
            r.batchid = cmdbid.Text;
            r.sid = cmbsid.Text;
            r.edate = DateTime.Parse(txtedate.Text);
            tc.enrollments.Add(r);
            tc.SaveChanges();
            MessageBox.Show("saved successfully");
            txtedate.Clear();

        }

        private void AddEnrollmentDetails_Load(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();

            foreach (var item in tc.batches)
            {
                cmdbid.Items.Add(item.batchid).ToString();
            }
            TechproEntities te = new TechproEntities();

            foreach (var item in te.students)
            {
                cmbsid.Items.Add(item.sid).ToString();
            }
        }
    }
}
