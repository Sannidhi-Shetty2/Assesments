﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class MdiForm : Form
    {
        public MdiForm()
        {
            InitializeComponent();
        }

        private void addStudentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddStudentDetails ae = new AddStudentDetails();
            ae.MdiParent = this;
            ae.Show();
        }

        private void addCourseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddCourseDetails ac = new AddCourseDetails();
            ac.MdiParent = this;
            ac.Show();
        }

        private void addBatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBatchDetails ab = new AddBatchDetails();
            ab.MdiParent = this;
            ab.Show();

        }

        private void addEnrollmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEnrollmentDetails ad = new AddEnrollmentDetails();
            ad.MdiParent = this;
            ad.Show();
        }

        private void studentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowStudentDetails sd = new ShowStudentDetails();
            sd.MdiParent = this;
            sd.Show();
        }

        private void courseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowCourseDetails sc = new ShowCourseDetails();
            sc.MdiParent = this;
            sc.Show();
        }

        private void batchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowBatchDetails sb = new ShowBatchDetails();
            sb.MdiParent = this;
            sb.Show();
        }

        private void enrollmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowEnrollmentDetails se = new ShowEnrollmentDetails();
            se.MdiParent = this;
            se.Show();
        }
    }
}
