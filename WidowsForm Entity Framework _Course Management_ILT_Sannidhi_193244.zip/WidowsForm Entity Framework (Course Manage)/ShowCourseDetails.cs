﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class ShowCourseDetails : Form
    {
        public ShowCourseDetails()
        {
            InitializeComponent();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            dataGridView1.DataSource = tc.courses.ToList();
        }

        private void ShowCourseDetails_Load(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            foreach(var  item in tc.courses)
            {
                cmbcid.Items.Add(item.courseid).ToString();
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = from c in tc.courses.ToList() where c.courseid == cmbcid.Text select c;
            dataGridView1.DataSource = v.ToList();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = (from b in tc.batches join r in tc.enrollments on b.batchid equals r.batchid group b by b.courseid into f select f);
                                                                                                            // new { CourseID = g.Key, NoOfStudents = g.Count() }).ToList();
            var v1 = (from c in tc.courses join t in v on c.courseid equals t.Key  select new { CourseID = t.Key, CourseName = c.coursename, NoOfStudent = t.Count(), TotalFees = t.Count() * c.coursefees }).ToList();
            dataGridView1.DataSource = v1.ToList();
                      
        }
    }
}
