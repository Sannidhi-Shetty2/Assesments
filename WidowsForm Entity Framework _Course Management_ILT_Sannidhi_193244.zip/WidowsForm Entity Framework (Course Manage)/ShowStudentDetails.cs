﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class ShowStudentDetails : Form
    {
        public ShowStudentDetails()
        {
            InitializeComponent();
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            dataGridView1.DataSource = tc.students.ToList();
        }

        private void ShowStudentDetails_Load(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            foreach(var item in tc.students)
            {
                cmbsid.Items.Add(item.sid).ToString();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = (from c in tc.courses
                     join b in tc.batches on c.courseid equals b.courseid
                     join r in tc.enrollments on b.batchid
                     equals r.batchid
                     join s in tc.students on r.sid equals s.sid
                     where s.sid == cmbsid.Text
                     select new { c.courseid, c.coursename, c.courseduration, c.coursecategory,
                         c.coursefees }).ToList();
            dataGridView1.DataSource = v.ToList();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = (from b in tc.batches join r in tc.enrollments on b.batchid 
                     equals r.batchid join s in tc.students on r.sid equals s.sid 
                     where s.sid == cmbsid.Text select new { b.batchid, b.bsdate, b.bstrength }).ToList();
            dataGridView1.DataSource = v.ToList();
        }
    }
}
