﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class ShowBatchDetails : Form
    {
        public ShowBatchDetails()
        {
            InitializeComponent();
        }

        private void ShowBatchDetails_Load(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            foreach(var item in tc.batches)
            {
                cmbbid.Items.Add(item.batchid).ToString();
            }
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            dataGridView1.DataSource = tc.batches.ToList();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = from b in tc.batches where b.batchid == cmbbid.Text select b;
            dataGridView1.DataSource = v.ToList();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            var v = from r in tc.enrollments group r by r.batchid into f select f;
            var v1 = (from b in tc.batches join t in v on b.batchid equals t.Key 
                      select new { BatchID = t.Key, NoOfStudents = t.Count(), NoOfSeatsVacant = b.bstrength - t.Count() });
            dataGridView1.DataSource = v1.ToList();
        }
    }
}
