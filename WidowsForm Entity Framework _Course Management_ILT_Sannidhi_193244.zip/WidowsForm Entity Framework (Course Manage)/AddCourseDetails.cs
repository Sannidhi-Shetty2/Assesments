﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentCourseManagementFormEntity
{
    public partial class AddCourseDetails : Form
    {
        public AddCourseDetails()
        {
            InitializeComponent();
        }

        private void btnsave2_Click(object sender, EventArgs e)
        {
            TechproEntities tc = new TechproEntities();
            course c = new course();
            c.courseid = txtcid.Text;
            c.coursename = txtcname.Text;
            c.courseduration = int.Parse(txtcduration.Text);
            c.coursecategory = txtccategory.Text;
            c.coursefees = int.Parse(txtcfees.Text);
            tc.courses.Add(c);
            tc.SaveChanges();
            MessageBox.Show("Saved Successfully");
            
        }

        private void txtcduration_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcfees_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtccategory_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcid_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
