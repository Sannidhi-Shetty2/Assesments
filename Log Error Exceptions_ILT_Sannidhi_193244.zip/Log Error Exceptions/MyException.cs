﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LogErrorInText
{

    class MyCalculator
    {
        public int Div(int a, int b)
        {
           
            return a / b;
        }
    }

}
