﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LogErrorInText
{
    class Program
    {
        
        public static void Main(string[] args)
        {
            try
            {
                MyCalculator obj =
                      new MyCalculator();
                int r = obj.Div(800, 0);
                Console.WriteLine("Result={0}", r);
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                string filePath = @"C:\Users\SAMPATH SHETTY\OneDrive\Desktop\ErrorTextFile.txt";

                using (StreamWriter writer = File.AppendText(filePath))
                {
                    writer.WriteLine("--------------------------------------------------");
                    writer.WriteLine("Error Information");
                    writer.WriteLine("Date : " + DateTime.Now.ToString("dddd") );
                    writer.WriteLine("Date : " + DateTime.Now.ToString()) ;
                    writer.WriteLine("IpAddr : 120.80.70.30");
                    writer.WriteLine("ClientProjectName: Vodaphone");

                    writer.WriteLine(ex.GetType().FullName);
                    writer.WriteLine("Message : " + ex.Message);
                    writer.WriteLine("StackTrace : " + ex.StackTrace);
                }
                
                string fp = @"C:\Users\SAMPATH SHETTY\OneDrive\Desktop\ErrorTextFile.txt";
                
                    using (StreamReader file = new StreamReader(fp))
                    {
                        int counter = 0;
                        string ln;

                        while ((ln = file.ReadLine()) != null)
                        {
                            Console.WriteLine(ln);
                            counter++;
                        }
                        file.Close();
                        Console.WriteLine("File has {counter} lines.");
                        Console.ReadLine();

                    }
                

            }
            
        }
    }
}
